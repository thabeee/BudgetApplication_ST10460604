package com.example.budgetapplication
//ST10460604 Thabile Ntimbane//
import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val button4 = findViewById<Button>(R.id.button4)
        button4.setOnClickListener {
            val message = "View Details button clicked"
            Toast.makeText(this@MainActivity2, message, Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)
        }

        val button3 = findViewById<Button>(R.id.button3)
        button3.setOnClickListener {
            onBackPressed()
        }



        }

}